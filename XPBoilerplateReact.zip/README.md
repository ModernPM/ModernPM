# React-Redux boilerplate

## Iniciando um novo projeto baseado no boilerplate

Criar uma pasta vazia para o repositório do novo projeto

`cd pasta-do-novo-projeto`

Clonar o boilerplate nessa pasta

`git clone https://xpinvestimentos.visualstudio.com/Projetos/_git/XPBoilerplateReact .`

Remover referências para o repositório do boilerplate

`git remote remove origin`

Referenciar o repositório (vazio) do novo projeto.

`git remote add origin <url repositorio do novo projeto>`

Enviar código do boilerplate (histórico incluso) para o novo repositório. Caso o novo repositório não esteja vazio (com conteúdo irrelevante, como o README.md default, usar a flag --force)

`git push --set-upstream origin master`

O novo repositório estará pronto para seguir o git-flow normalmente. Recomenda-se bloquear a branch master para push (somente pull-requests) e revogar quaisquer permissões de force-push.

## Customizando estilo

O estilo do boilerplate está separado por variaveis. Porém, caso seja necessário, essas variaveis podem ser sobrescritas da seguinte forma:

- **Crie um arquivo global com as variaveis de estilo**

  Em `src/styles` crie um arquivo `variables.scss` e import as variaveis responsaveis pelo estilo padrão do boilerplate `@import '~xp-components-react/dist/scss/variables.scss'`.

- **Sobrescreva as variaveis**

  Por exemplo: A variavel `$color-secondary: #FFC709` pode ser alterado para `$color-secondary: #000;`.

- **Importe as variaveis para aplicação**

  Importe o seu arquivo de variaveis em `src/App.jsx` desta forma `import 'styles/variables.scss'`.

## CORS

O endpoint usado para o exemplo ([GET] fundos de investimentos) não está configurado para aceitar CORS. Para fazer a requisição funcionar, é necessário instalar uma extensão no browser como esta: [cors-toggle](https://chrome.google.com/webstore/detail/cors-toggle/jioikioepegflmdnbocfhgmpmopmjkim?utm_source=chrome-app-launcher-info-dialog)

## Scripts

- `yarn install`

  Instala dependências

- `yarn start`

  Executa servidor de desenvolvimento

- `yarn test`

  Executa testes

- `yarn build`

  Gera os arquivos de produção no diretório build-prod

- `yarn lint`

  Executa o eslint apontando os erros no código em arquivos js e jsx (indentação, variaáeis não utilizadas, finais de linha, etc)

- `yarn lint:fix`

  Conserta problemas encontrados pelo eslint. ATENÇÃO alguns tipos de problemas devem ser resolvidos manualmente

- `yarn stylelint`

  Executa o stylelint apontando os erros no código em arquivos scss (indentação, variáveis não utilizadas, finais de linha, etc)

- `yarn stylelint:fix`

  Conserta problemas encontrados pelo stylelint. ATENÇÃO alguns tipos de problemas devem ser resolvidos manualmente

- `yarn cypress`

  Abre o Cypress em modo GUI, para assistir no desenvolvimento, utilizando o Chrome com as ferramentas  de debugging e testes fornecidas pelo framework.

- `yarn test:integration`

  Roda os testes de integração do Cypress em modo headless, via console, gerando artefatos de video e screenshots em caso de erros.

- `yarn test:integration:report`

  Roda os testes de integração do Cypress em modo headless, via console, gerando artefatos de video, screenshots em caso de erro e um relatório em XML para incorporação no CI.

## Padrão de Commit

- `chore: your message`
- `feat: your message`
- `fix: your message`
- `refactor: your message`
- `style: your message`
- `test: your message`

## Git Flow

- [wiki](https://xpinvestimentos.visualstudio.com/Projetos/Previd%C3%AAncia/_wiki/wikis/Projetos.wiki?wikiVersion=GBwikiMaster&pagePath=%2Fsquads%2Fprevidencia%2Ffrontend%2Fgit%20flow)

## Estrutura de pastas e arquivos

Esta estrutura foi organizada para que facilite a manutenção e incrementação do código, é fundamental que ela seja seguida.

### Arquivos Principais

- `src/redux-flow/index.logic.js`

  Arquivo de configuração da store.

- `src/redux-flow/reducers/index.logic.js`

  Arquivo onde todos os reducers devem ser importados.

- `src/redux-flow/logics/index.logic.js`

  Arquivo de configuração do **redux-logic**, onde todos os logics usados pelos containers devem ser importados e configurados.

- `src/index.logic.js`:`src/index.html`:`src/App.jsx`

  São arquivos de configuração da aplicação. Estes arquivos só são alterados mediante a uma importante mudança na estrutura da aplicação.

### Diretorios

- `config/`

  Configurações base do projeto.

- `config/enviroments/`

  Variáveis de ambiente.

- `config/webpack/`

  Bundle do projeto.

- `test/`

  Testes globais da aplicação, por hora só contempla os testes de integração **e2e**.

- `src/`

  Todo o código source da applicação deve ser mantido nesse diretório.

- `src/containers/`

  Os componentes que conectam com a store devem ser criados no diretório containers, existem 3 diretórios nessa estrutura.

  - `src/containers/Common`

    Containers em comum com a aplicação.

  - `src/containers/Features`

    Containers separados por **funcionalidades**.

  - `src/containers/Routes`

    Rotas principais da aplicação separadas por funcionalidades.

- `src/components`

  Os componentes que não conectam com a store devem ser criados no diretório components. Temos 3 divisões de components nesse diretório:

  - `src/components/Common/`

    Aqui será mantido components que são de uso comum em toda a aplicação, mas que ainda não estão maduros o suficiente para ir pro `xp-components`

  - `src/components/Features/`

    Aqui sera mantido componentes separados por funcionalidades.

  - `src/components/Routes`

    Aqui sera mantido as rotas por funcionalidades.

- `src/reducers`

  Neste diretório fica o arquivo de configuração index.logic.js, onde os reducers atrelados aos containers devem ser importados e configurados. Os reducers que não estão atrelados a componentes devem ser criados neste diretório.

- `src/utils`

  Aqui devem ser mantidos os arquivos.

  - `src/utils/api`

    Aqui deve ser mantido os endpoints das API's

  - `src/utils/helpers`

    Aqui deve ser mantido funções helpers, por exemplo: uma função que retorna uma data em determinado formato que é usado em vários arquivos. Essas funções devem ser puras, ou seja, não devem causar side effects.

  - `src/utils/initializers`

    Aqui deve ser mantido funções que precisam ser inicializadas no start da aplicação. exemplo: ferramenta de performance, track de BI, ou chamada de uma action para popular a store.

  - `src/utils/interceptors`

    Aqui deve ser mantido utils que precisam ser chamados em requisições Ajax, no request e no response.

- `src/styles`

  Arquivos de style globais devem ser criados neste diretório.

#### Components

Cada componente deve ter seu próprio diretório dentro de uma das pasta /components. Dentro do diretório do componente, devem conter os arquivos index.jsx e styles.scss e uma subpasta /tests e eventuais atom-componentes que o compoem, esses atom-componentes devem ser criados da mesma forma que o componente pai dele.

#### Containers

Cada container deve ter seu próprio diretório dentro de uma das pastas /containers. Dentro do diretório do componente devem conter os arquivos index.jsx, reducer.js, actions.js, constants.js, logic.js, style.scss(caso precise) e uma subpasta /tests.

```
Diferença entre containers e components:
- Containers: É função do container fazer uma conecção com a store para requisitar os dados que serão renderizados pelos componentes. Nele são defidas regras de negócios que acionarão actions para atualizar o estado da aplicação.

- Componentes: Renderizam informações vindas dos containers, de constantes ou de variáveis de estado. Podem ou não conter um estado, mas não irão conectar com a store. Podem ser formulários, modais, botões e labels.
```

##### index.jsx

Arquivo que retorna o conteúdo que será renderizado.

##### style.scss

É onde ficará todo o style do componente/container referenciado.

##### /tests

Neste diretório ficarão todos os arquivos de testes do componente/container. Caso seja um container, os testes do actions, reducer e logic também ficam neste diretório. Caso o teste gere um spashot, a subpasta __snapshots__ é criada contendo os snapshots referentes ao teste.

##### reducer.js

É o reducer atrelado ao container.

##### actions.js

É onde ficam as actions utilizadas pelo container.

##### constants.js

É onde ficam as constantes usadas pelas actions, reducers, ou constantes específicas deste componente/container.

##### logic.js

Arquivo que faz o gerenciamento de chamadas assíncronas através do middleware redux-logic.

#### Estrutura dos testes de integração - Cypress

A pasta Cypress fornece uma estrutura básica, com exemplos, de cada elemento usado para o desenvolvimento dos testes de integração, sendo o principal o arquivo spec na pasta cypress/integration, que possui um exemplo feito com base nos components do boilerplate.

#### Rodando Cypress em modo GUI para desenvolvimento

Primeiro, rode o servidor com `yarn start` e após rode o `yarn cypress`.
