const presets = [
  '@babel/preset-env',
  [
    '@babel/preset-react',
    {
      development: process.env.BABEL_ENV === 'development',
    },
  ],
];

const plugins = [
  [
    'babel-plugin-styled-components',
    {
      displayName: process.env.BABEL_ENV === 'development',
    },
  ],
  '@babel/plugin-proposal-class-properties',
  '@babel/plugin-transform-runtime',
  ['module-resolver', {
    root: ['./src'],
  }],
];

module.exports = { presets, plugins };
