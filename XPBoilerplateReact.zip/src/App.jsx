import React from 'react';
import { Provider } from 'react-redux';
import { ThemeProvider } from 'styled-components';
import Yield from '@xpi-ui/styles/yield';

import ResetCss from './utils/reset-css';
import Store from './redux-flow/index.store';

import Routes from './routes';

const App = () => (
  <Provider store={Store}>
    <ThemeProvider theme={Yield}>
      <>
        { Routes() }
        <ResetCss />
      </>
    </ThemeProvider>
  </Provider>
);

export default App;
