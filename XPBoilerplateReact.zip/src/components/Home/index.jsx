import React from 'react';
import styled from 'styled-components';

const Div = styled.div`
  padding: 8px;
  border: 1px solid darkgoldenrod;
`;

const Home = () => (
  <Div>
    <p>
      {'Lista de Fundos'}
    </p>
  </Div>
);

export default Home;
