import React from 'react';
import { shallow } from 'enzyme';

import Home from '../../Home';

describe('Home', () => {
  let props;

  beforeEach(() => {
    props = {
      tableFunds: {
        header: [],
      },
    };
  })

  it('Should render correctly', () => {
    const component = shallow(<Home {...props} />);

    expect(component).toBeTruthy();
  });
});
