import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import styled from 'styled-components';

import { LoadFunds } from '../../redux-flow/actions/funds';
import Home from '../../components/Home';

const P = styled.p`
  font-size: 50px;
  color: goldenrod;
  margin: 0 0 20px 0;
`;

class HomePage extends Component {
  static propTypes = {
    loadFundsDispatch: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);

    props.loadFundsDispatch();
  }

  render() {
    return (
      <>
        <P>
          {'Boilerplate'}
        </P>

        <Home />
      </>
    );
  }
}

const mapStateToProps = ({ FundsReducer }) => ({
  headerTable: FundsReducer.headerTable,
  listFunds: FundsReducer.list,
});

const mapDispatchToProps = dispatch => ({
  loadFundsDispatch: () => dispatch(LoadFunds()),
});

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
