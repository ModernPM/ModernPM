import React from 'react';
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';

import HomePage from '../../HomePage';

describe('HomePage', () => {
  const initialState = {
    FundsReducer: {
      headerTable: [{}],
      listFunds: [{}],
      loadFundsDispatch: () => ({}),
    },
  };

  const mockStore = configureStore();
  let store;
  let container;

  beforeEach(()=>{
    store = mockStore(initialState);
    container = mount(<HomePage store={store} />);
  })

  it('Should render correctly', () => {
    expect(container).toBeTruthy();
  });
});
