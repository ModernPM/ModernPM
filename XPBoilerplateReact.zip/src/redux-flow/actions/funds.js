import {
  LOAD_FUNDS,
  LOAD_FUNDS_SUCCESS,
} from '../constants/funds';

export const LoadFunds = () => ({
  type: LOAD_FUNDS,
});

export const LoadFundsSuccess = payload => ({
  type: LOAD_FUNDS_SUCCESS,
  payload,
});
