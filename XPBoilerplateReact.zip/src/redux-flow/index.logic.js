import Funds from './logics/funds';

export default [
  Funds,
];
