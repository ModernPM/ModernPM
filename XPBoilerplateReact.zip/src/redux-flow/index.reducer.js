import { combineReducers } from 'redux';
import FundsReducer from './reducers/funds';

const reducers = combineReducers({
  FundsReducer,
});

export default reducers;
