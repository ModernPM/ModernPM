import { createLogic } from 'redux-logic';
import { LOAD_FUNDS } from '../constants/funds';
import { LoadFundsSuccess } from '../actions/funds';

export default createLogic({
  type: LOAD_FUNDS,
  latest: true,

  process({ requestUtil }, dispatch, done) {
    const URL = 'http://sak-front.xpi.com.br:21062/api/v1/brands/3/investment-funds';

    requestUtil(URL)
      .then((success) => {
        dispatch(LoadFundsSuccess(success.data));
      }).then(done);
  },
});
