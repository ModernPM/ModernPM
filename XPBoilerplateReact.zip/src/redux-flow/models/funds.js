export default data => ({
  id: data.id,
  name: data.name,
});
