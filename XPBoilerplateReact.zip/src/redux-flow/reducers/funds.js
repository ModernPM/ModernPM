import { LOAD_FUNDS_SUCCESS } from '../constants/funds';
import ListFundsModel from '../models/funds';

const HEADER_TABLE = [
  {
    title: 'ID',
    order: true,
    dataIndex: 'id',
  },
  {
    title: 'Nome',
    order: true,
    dataIndex: 'name',
  },
];

const FUND_INIT = {
  headerTable: HEADER_TABLE,
  list: [],
};

export default (state = FUND_INIT, action) => {
  switch (action.type) {
    case LOAD_FUNDS_SUCCESS:
      return {
        ...state,
        list: action.payload.map(item => ListFundsModel(item)),
      };
    default:
      return state;
  }
};
