import React from 'react';
import {
  Router,
  Route,
  IndexRoute,
  hashHistory,
} from 'react-router';

import HomePage from './containers/HomePage';

export default () => (
  <Router history={hashHistory}>
    <Route path="/">
      <IndexRoute component={HomePage} />
      <Route />
    </Route>
  </Router>
);
