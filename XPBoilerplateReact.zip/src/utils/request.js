import Axios from 'axios';
import ApiError from './apiError';

const parseJSON = response => response.data;

const throwError = (json, status) => {
  throw new ApiError(status, json);
};

const checkStatus = (response) => {
  if (response.status >= 200 && response.status < 300) {
    return response;
  }
  return response.json().then(json => throwError(json, response.status));
};

const request = async (url, options = {}) => {
  try {
    const response = await Axios(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...options.headers,
      },
      ...options,
    });

    const checked = await checkStatus(response);
    return parseJSON(checked);
  } catch (e) {
    /* eslint-disable no-console */
    console.warn(e);

    return false;
  }
};

export default request;
