import { createGlobalStyle } from 'styled-components';

const styledObject = createGlobalStyle`
  body {
    font-size: 16px;
    font-family: ${props => props.theme.primaryFont};
  }
`;

export default styledObject;
