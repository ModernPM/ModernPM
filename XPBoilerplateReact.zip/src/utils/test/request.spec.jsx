import React from 'react';
import axios from 'axios';

import Request from '../../utils/request';

jest.mock('axios');

describe('Utils/Request', () => {
  let options;  
  let successData;  
  let exceptionData;

  beforeEach(() => {
    options = {
      headers: {},
    };
    
    successData = {
      status: 200,
      data: {},
    };
    
    exceptionData = {
      status: 400,
      json: () => (
        Promise.resolve({
          name: 'Lorem Ipsum',
          message: 'Lorem Ipsum',
        })
      ),
    };
  });

  it('Should request an URL successfully', async () => {
    axios.mockResolvedValue(successData);

    const request = await Request('https://www.xpi.com.br/', options);

    expect(request).toBeTruthy();
  });

  it('Should throws an exception', async () => {
    axios.mockResolvedValue(exceptionData);

    const request = await Request('https://www.xpi.com.br/');

    expect(request).toBeFalsy();
  });
});
