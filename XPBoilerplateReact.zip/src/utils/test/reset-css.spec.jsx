import React from 'react';
import { mount } from 'enzyme';

import ResetCSS from '../../utils/reset-css';

describe('Utils/ResetCSS', () => {
  let props;

  beforeEach(() => {
    props = {
      theme: {
        primaryFont: true,
      },
    };
  });

  it('Should get a styled object', async () => {
    const object = mount(<ResetCSS {...props} />);

    expect(object).toBeTruthy();
  });
});
