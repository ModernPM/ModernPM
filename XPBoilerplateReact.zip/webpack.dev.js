const path = require('path');
/* eslint import/no-extraneous-dependencies: ["error", {"devDependencies": true}] */
const merge = require('webpack-merge');
const common = require('./webpack.common.js');

module.exports = merge(common, {
  mode: 'development',
  stats: 'normal',
  devtool: 'inline-source-map',
  devServer: {
    contentBase: path.resolve(__dirname, 'dist'),
    historyApiFallback: true,
    compress: true,
    port: 9000,
  },
});
